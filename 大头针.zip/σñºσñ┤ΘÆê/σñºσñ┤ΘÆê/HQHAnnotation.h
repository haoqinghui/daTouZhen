//
//  HQHAnnotation.h
//  大头针
//
//  Created by mac on 16/9/22.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>


@interface HQHAnnotation : NSObject <MKAnnotation>

@property (nonatomic,assign) CLLocationCoordinate2D coordinate;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *subtitle;

//大头针图片
@property(copy,nonatomic)NSString *imageName;

//配图图片
@property(copy,nonatomic)NSString *imageNameDesc;



@end
