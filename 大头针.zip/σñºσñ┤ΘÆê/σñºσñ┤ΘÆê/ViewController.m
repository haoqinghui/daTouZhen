//
//  ViewController.m
//  大头针
//
//  Created by mac on 16/9/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>
#import "HQHDaTouZhen.h"
#import "HQHAnnotation.h"


@interface ViewController ()<MKMapViewDelegate>
@property(nonatomic,strong)MKMapView *mapView;
@property(strong,nonatomic)CLLocationManager *manager;
//大头针详情
@property(nonatomic,strong)NSArray *dataArr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建定位管理器 对象
    CLLocationManager *manager = [[CLLocationManager alloc]init];
    self.manager = manager;
    //申请授权
    [manager requestAlwaysAuthorization];
    self.mapView.delegate = self;
    for (HQHDaTouZhen *datouzhen in self.dataArr) {
        
        
        //创建大头针模型  决定大头针视图的界面展示
        HQHAnnotation *anno = [[HQHAnnotation alloc]init];
        
        //初始化
        anno.coordinate = datouzhen.coordinate;
        //标题
        anno.title = datouzhen.title;
        //描述
        anno.subtitle = datouzhen.desc;
        
        anno.imageName = datouzhen.icon;
        
        anno.imageNameDesc = datouzhen.image;
        
        [self.mapView addAnnotation:anno];
    }
    
    
    
    
    
}

-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation{
    static NSString *ID = @"anno";
    MKAnnotationView *annoView = [mapView dequeueReusableAnnotationViewWithIdentifier:ID];
    if (annoView == nil) {
        annoView = [[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:ID];
        //title 不显示  如果自定义了设置了图片 就不显示
        annoView.canShowCallout = YES;
        
        
    }
    
    
    //取出大头针模型对象
    HQHAnnotation *anno = (HQHAnnotation *)annotation;
    
    
    //  自定义
    annoView.image = [UIImage imageNamed:anno.imageName];
    
    
    //显示自定义详情
    UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:anno.imageNameDesc]];
    
    UIView *myView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 100, 50)];
    myView.backgroundColor = [UIColor redColor];
    
    [myView addSubview:imageView];
    imageView.frame = myView.bounds;
    
    annoView.leftCalloutAccessoryView = myView;
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    btn.backgroundColor = [UIColor blackColor];
    [btn setTitle:@"详情" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    annoView.rightCalloutAccessoryView = btn;
    
    
    
    
    
    
    return annoView;

}


- (void)btnClick:(UIButton *)btn
{
    NSLog(@"btnClick");
}







-(NSArray *)dataArr{
    if (_dataArr==nil) {
        HQHDaTouZhen *datouz=[[HQHDaTouZhen alloc]init];
        datouz.title=@"酒店";
        datouz.desc=@"此处有吃有睡";
        datouz.icon=@"category_1";
        datouz.image=@"touxiang";
        datouz.coordinate = CLLocationCoordinate2DMake(39, 116);
        _dataArr = @[datouz];
        
    }
    return _dataArr;
}


-(MKMapView *)mapView{
    if (_mapView==nil) {
        _mapView=[[MKMapView alloc]init];
        [self.view addSubview:_mapView];
        _mapView.frame=self.view.bounds;
    }
    return _mapView;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
