//
//  HQHDaTouZhen.h
//  大头针
//
//  Created by mac on 16/9/21.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
@interface HQHDaTouZhen : NSObject

//标题
@property(nonatomic,copy)NSString *title;
//描述
@property(nonatomic,copy)NSString *desc;
//图标
@property(nonatomic,copy)NSString *icon;
//配图
@property(nonatomic,copy)NSString *image;
//图标的位置
@property(nonatomic,assign)CLLocationCoordinate2D coordinate;


@end
